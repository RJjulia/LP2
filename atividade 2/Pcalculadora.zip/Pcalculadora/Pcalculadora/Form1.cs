namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            // limpar campos
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
            txtNum1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            // fechar form
            Close();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (Double.TryParse(txtNum1.Text, out Num1) &&
                Double.TryParse(txtNum2.Text, out Num2))
            {
                //soma
                double Resultado;
                Resultado = Num1 + Num2;
                txtResultado.Text = Resultado.ToString("N2");
               

            }
            else
            {
                //  valor invalido (incluindo vazio)
                MessageBox.Show("Digite novamente!");
                txtNum1.Focus();

            }
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (Double.TryParse(txtNum1.Text, out Num1) &&
                Double.TryParse(txtNum2.Text, out Num2))
            {
                // subtra��o
                double Resultado;
                Resultado = Num1 - Num2;
                txtResultado.Text = Resultado.ToString("N2");

            }
            else
            {
                MessageBox.Show("Digite novamente!");
                txtNum1.Focus();

            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (Double.TryParse(txtNum1.Text, out Num1) &&
                Double.TryParse(txtNum2.Text, out Num2))
            {
                // multiplica��o
                double Resultado;
                Resultado = Num1 * Num2;
                txtResultado.Text = Resultado.ToString("N2");

            }
            else
            {
                MessageBox.Show("Digite novamente!");
                txtNum1.Focus();

            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            double Num1, Num2;

            if (Double.TryParse(txtNum1.Text, out Num1) &&
                Double.TryParse(txtNum2.Text, out Num2))
            {
                if ((Num1 != 0) && (Num2 != 0)) // teste a mais caso haja div por 0
                {
                    //divis�o
                    double Resultado;
                    Resultado = Num1 / Num2;
                    txtResultado.Text = Resultado.ToString("N2");
                }
                else if ((Num1 == 0) || (Num2 == 0))
                {
                    // aviso caso algum valor for 0
                    MessageBox.Show("Divis�o impossivel! Tente Outros Valores :)");
                    txtNum1.Focus();
                }
                    

            }
            else
            {
                MessageBox.Show("Digite novamente!");
                txtNum1.Focus();

            }
        }
    }
}