namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
            
            txtLado1.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double A, B, C;

            if( !Double.TryParse(txtLado1.Text, out A) ||
                !Double.TryParse(txtLado2.Text, out B) ||
                !Double.TryParse(txtLado3.Text, out C))
            {
                MessageBox.Show("Os valores devem ser num�ricos!");
            }
           else
            {
                if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) &&
                   B > Math.Abs(A - C) && C < (A + B) && C > Math.Abs(A - B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("Tri�ngulo equil�tero");
                    }
                    else if (A != B && B != C)
                    {
                        MessageBox.Show("Tri�ngulo escaleno");
                    }
                    else
                        MessageBox.Show("Triangulo is�sceles");
                }
                else
                    MessageBox.Show("Impossivel formar um tri�ngulo com esses valores");
            }
        }
    }
}