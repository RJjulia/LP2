namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtimc.Clear();

            txtPeso.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        double Peso, Altura;
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //double Peso, Altura;
            if (Double.TryParse(txtPeso.Text, out Peso) &&
                Double.TryParse(txtAltura.Text, out Altura))
            {
                if ((Peso <= 0) || (Altura <= 0))
                {
                    MessageBox.Show("Peso e Altura Devem ser maior que 0");
                    txtPeso.Focus();
                }
                else
                {
                    double imc;

                    imc = Peso / Math.Pow(Altura, 2);

                    imc = Math.Round(imc, 1); // arrendodando para uma casa decimal

                    txtimc.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        MessageBox.Show("Magreza");
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal");
                    else if (imc <= 29.9)
                        MessageBox.Show("Sobre Peso");
                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade grave");
                }
            }
            else
                MessageBox.Show("Valores invalidos");
        }
    }
}