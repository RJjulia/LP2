﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblimc = new System.Windows.Forms.Label();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.fotoBoxImc = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.fotoBoxImc)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(74, 194);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(38, 15);
            this.lblPeso.TabIndex = 0;
            this.lblPeso.Text = "PESO:";
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(74, 259);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(52, 15);
            this.lblAltura.TabIndex = 2;
            this.lblAltura.Text = "ALTURA:";
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(151, 186);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(274, 23);
            this.txtPeso.TabIndex = 3;
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(151, 251);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(274, 23);
            this.txtAltura.TabIndex = 4;
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.LightGreen;
            this.btnLimpar.Location = new System.Drawing.Point(51, 388);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(112, 65);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.LightGreen;
            this.btnSair.Location = new System.Drawing.Point(362, 388);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(112, 65);
            this.btnSair.TabIndex = 6;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.LightGreen;
            this.btnCalcular.Location = new System.Drawing.Point(210, 388);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(112, 65);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(74, 332);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(32, 15);
            this.lblimc.TabIndex = 8;
            this.lblimc.Text = "IMC:";
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(151, 324);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(274, 23);
            this.txtimc.TabIndex = 9;
            // 
            // fotoBoxImc
            // 
            this.fotoBoxImc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fotoBoxImc.BackgroundImage")));
            this.fotoBoxImc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fotoBoxImc.Location = new System.Drawing.Point(190, 36);
            this.fotoBoxImc.Name = "fotoBoxImc";
            this.fotoBoxImc.Size = new System.Drawing.Size(168, 100);
            this.fotoBoxImc.TabIndex = 10;
            this.fotoBoxImc.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(539, 540);
            this.Controls.Add(this.fotoBoxImc);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lblPeso);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.fotoBoxImc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblPeso;
        private Label lblAltura;
        private TextBox txtPeso;
        private TextBox txtAltura;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnCalcular;
        private Label lblimc;
        private TextBox txtimc;
        private PictureBox fotoBoxImc;
    }
}